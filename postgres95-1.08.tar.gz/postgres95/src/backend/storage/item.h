/*-------------------------------------------------------------------------
 *
 * item.h--
 *    POSTGRES disk item definitions.
 *
 *
 * Copyright (c) 1994, Regents of the University of California
 *
 * $Id: item.h,v 1.1.1.1 1996/07/09 06:21:52 scrappy Exp $
 *
 *-------------------------------------------------------------------------
 */
#ifndef	ITEM_H
#define ITEM_H

#include "c.h"

typedef Pointer	Item;

#endif	/* ITEM_H */
