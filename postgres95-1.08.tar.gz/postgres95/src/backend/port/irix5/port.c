/*-------------------------------------------------------------------------
 *
 * port.c--
 *    Irix5-specific routines
 *
 * Copyright (c) 1994, Regents of the University of California
 *
 *
 * IDENTIFICATION
 *    /usr/local/devel/pglite/cvs/src/backend/port/sparc_solaris/port.c,v 1.2 1995/03/17 06:40:19 andrew Exp
 *
 *-------------------------------------------------------------------------
 */
#include <math.h>		/* for pow() prototype */

#include <errno.h>
