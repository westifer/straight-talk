#define BLCKSZ        8192
#define NOFILE		100
